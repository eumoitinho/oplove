-- =====================================================
-- POLÍTICAS RLS CORRETAS COM ESTRUTURA REAL
-- =====================================================

-- POSTS - Posts públicos visíveis para todos
DROP POLICY IF EXISTS "posts_select_public" ON posts;
CREATE POLICY "posts_select_public" 
ON posts FOR SELECT 
USING (visibility = 'public' OR user_id = auth.uid());

-- USERS - Perfis públicos  
DROP POLICY IF EXISTS "users_select_public" ON users;
CREATE POLICY "users_select_public" 
ON users FOR SELECT 
USING (true); -- Perfis são públicos

-- COMMENTS - Comentários de posts públicos (usa post_id)
DROP POLICY IF EXISTS "comments_select" ON comments;
CREATE POLICY "comments_select" 
ON comments FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM posts 
    WHERE posts.id = comments.post_id 
    AND (posts.visibility = 'public' OR posts.user_id = auth.uid())
  )
);

-- LIKES - Likes de posts públicos (usa target_id e target_type)
DROP POLICY IF EXISTS "likes_select" ON likes;
CREATE POLICY "likes_select" 
ON likes FOR SELECT 
USING (
  (target_type = 'post' AND EXISTS (
    SELECT 1 FROM posts 
    WHERE posts.id = likes.target_id 
    AND (posts.visibility = 'public' OR posts.user_id = auth.uid())
  ))
  OR
  (target_type = 'comment' AND EXISTS (
    SELECT 1 FROM comments c
    JOIN posts p ON p.id = c.post_id
    WHERE c.id = likes.target_id 
    AND (p.visibility = 'public' OR p.user_id = auth.uid())
  ))
);

-- FOLLOWS - Seguindo/seguidores visíveis
DROP POLICY IF EXISTS "follows_select" ON follows;
CREATE POLICY "follows_select" 
ON follows FOR SELECT 
USING (true); -- Temporariamente totalmente público

-- Verificar políticas criadas
SELECT tablename, policyname, cmd
FROM pg_policies
WHERE tablename IN ('posts', 'users', 'comments', 'likes', 'follows')
ORDER BY tablename, cmd;